#!/bin/bash
# Start both backend and frontend in parallel

echo "🌿 Starting Field Guide..."
echo ""

# Backend
(cd backend && pip install -r requirements.txt -q && uvicorn main:app --reload --port 8000) &
BACKEND_PID=$!

# Frontend
(cd frontend && npm install --silent && npm run dev) &
FRONTEND_PID=$!

echo "✅ Backend:  http://localhost:8000"
echo "✅ API docs: http://localhost:8000/docs"
echo "✅ Frontend: http://localhost:5173"
echo ""
echo "Press Ctrl+C to stop both."

trap "kill $BACKEND_PID $FRONTEND_PID 2>/dev/null; exit" INT TERM
wait
